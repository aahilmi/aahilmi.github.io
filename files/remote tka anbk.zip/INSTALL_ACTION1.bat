@echo off
:: Otomatis meminta hak akses Administrator (UAC Prompt) jika belum Run as Admin
net session >nul 2>&1
if %errorLevel% neq 0 (
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

:: Pindah ke direktori tempat file BAT ini berada di flashdisk
cd /d "%~dp0"

echo [1/2] Menginstall Action1 Agent secara latar belakang (silent)...
msiexec /i action1_agent.msi /qn

echo [2/2] Menunggu verifikasi service Windows...
timeout /t 5 /nobreak >nul

sc query "Action1 Agent" | find "RUNNING" >nul
if %errorLevel% equ 0 (
    echo.
    echo ==============================================
    echo SUKSES: Action1 Agent berhasil terpasang dan aktif!
    echo ==============================================
) else (
    echo.
    echo Instalasi selesai, service sedang sinkronisasi ke cloud Action1.
)

timeout /t 3 >nul
exit